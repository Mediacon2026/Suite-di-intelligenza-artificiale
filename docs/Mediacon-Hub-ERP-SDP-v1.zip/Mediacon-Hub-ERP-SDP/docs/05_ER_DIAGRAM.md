# 05 - ER Diagram

```mermaid
erDiagram
    organizations ||--o{ branches : has
    organizations ||--o{ users : has
    organizations ||--o{ contacts : has
    branches ||--o{ mediations : manages
    contacts ||--o{ mediation_parties : participates
    contacts ||--o{ mediators : can_be
    mediations ||--o{ mediation_parties : has
    mediations ||--o{ mediation_lawyers : has
    mediations ||--o{ mediation_meetings : has
    mediations ||--o{ mediation_fees : has
    mediations ||--o{ mediator_compensations : generates
    mediations ||--o{ documents : stores
    users ||--o{ audit_logs : creates
```
