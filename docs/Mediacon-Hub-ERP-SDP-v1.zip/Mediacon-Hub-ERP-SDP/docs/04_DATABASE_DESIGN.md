# 04 - Database Design

## Principi
Il database è relazionale, PostgreSQL, modulare e predisposto per multi-sede e multi-organizzazione.

## Tabelle core MVP
- organizations
- branches
- users
- roles
- permissions
- user_roles
- contacts
- contact_types
- documents
- tasks
- audit_logs

## Tabelle mediazione MVP
- mediators
- mediations
- mediation_parties
- mediation_lawyers
- mediation_meetings
- mediation_fees
- mediator_compensations
- dgstat_reports

## Tabelle estensioni future
- training_courses
- orientation_leads
- occ_cases
- business_crisis_cases
