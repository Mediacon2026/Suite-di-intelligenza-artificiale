# 09 - Use Cases

## UC-001 - Creazione contatto
Attore: Segreteria. Risultato: anagrafica unica creata e riutilizzabile.

## UC-002 - Apertura mediazione
Attore: Segreteria. Risultato: mediazione creata con numero interno, trimestre e stato iniziale.

## UC-003 - Chiusura mediazione
Attore: Mediatore/Responsabile. Risultato: esito registrato, durata calcolata, DGStat aggiornato.

## UC-004 - Generazione documento
Attore: Utente autorizzato. Risultato: PDF prodotto da modello e archiviato nella pratica.
