# 12 - AI Architecture

## Principio
Gli assistenti AI non sostituiscono l'utente, ma supportano controllo, riepilogo, redazione bozze e segnalazione anomalie.

## Agenti
- Mediazione AI: pratiche, verbali, convocazioni, DGStat, documenti mancanti.
- OCC AI: debitori, creditori, passivo, relazione, scadenze.
- Orientamento AI: lead, offerte, preventivi, follow-up.
- Formazione AI: corsi, attestati, presenze.
- Direzione AI: KPI, report, anomalie.

## Limiti
Ogni output AI deve essere revisionabile dall'utente prima dell'uso ufficiale.
