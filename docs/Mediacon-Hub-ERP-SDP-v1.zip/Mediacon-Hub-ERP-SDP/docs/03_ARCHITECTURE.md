# 03 - Architecture

## Stack
- Frontend: React.
- Backend: FastAPI.
- Database: PostgreSQL.
- Autenticazione: JWT.
- PDF: motore documentale server-side.
- AI: integrazione tramite servizi esterni.
- Deploy: Docker + Nginx.

## Moduli
- Core: utenti, ruoli, sedi, permessi, configurazioni.
- CRM: contatti unici.
- Mediazione: pratiche, parti, avvocati, incontri, esiti, DGStat.
- Documentale: upload, modelli, PDF.
- Contabilità: pagamenti, incassi, compensi.
- AI: assistenti specializzati.

## Workflow engine
Ogni pratica deve avanzare per stati controllati. Ogni passaggio importante deve essere registrato nello storico.
