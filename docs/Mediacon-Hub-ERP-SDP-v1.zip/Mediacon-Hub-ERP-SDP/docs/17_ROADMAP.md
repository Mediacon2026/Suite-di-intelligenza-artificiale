# 17 - Roadmap

## v1.0
Core, CRM, Mediazioni, Indennità, Documentale, DGStat, Dashboard.

## v1.1
Formazione e attestati.

## v1.2
Polo Orientamento.

## v2.0
OCC, Sovraindebitamento, Crisi d'Impresa, Advisor.

## v3.0
AI avanzata, workflow configurabili, integrazioni PEC/firma/calendario.
