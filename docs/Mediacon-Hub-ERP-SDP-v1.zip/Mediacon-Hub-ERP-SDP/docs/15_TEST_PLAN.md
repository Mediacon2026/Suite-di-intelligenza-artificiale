# 15 - Test Plan

## Test MVP
- Login corretto/non corretto.
- Creazione contatto.
- Ricerca contatto.
- Creazione mediazione.
- Assegnazione numero annuale.
- Calcolo trimestre.
- Inserimento parti e avvocati.
- Inserimento incontro.
- Chiusura mediazione.
- Report DGStat.
- Upload documento.

## Criterio di accettazione
Nessuna funzione critica deve produrre dati incoerenti o duplicati.
