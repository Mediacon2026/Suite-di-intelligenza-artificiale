# 08 - User Stories

## Core
US-001: Come amministratore voglio creare utenti con ruoli diversi.
US-002: Come amministratore voglio gestire le sedi.
US-003: Come utente voglio accedere con email e password.

## CRM
US-004: Come segreteria voglio creare un contatto unico.
US-005: Come utente voglio cercare un contatto per nome, PEC, email, CF o P.IVA.

## Mediazione
US-006: Come segreteria voglio aprire una nuova mediazione.
US-007: Come sistema voglio assegnare il numero interno annuale.
US-008: Come sistema voglio calcolare il trimestre DGStat.
US-009: Come responsabile voglio generare il report DGStat.
US-010: Come sistema voglio calcolare indennità e compensi.
