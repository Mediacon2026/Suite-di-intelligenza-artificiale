# 02 - Requirements

## Requisiti funzionali principali
- Gestione utenti, ruoli e permessi.
- Gestione sedi.
- CRM unico dei contatti.
- Gestione mediazioni con parti, avvocati, mediatori, incontri, esiti.
- Numerazione interna annuale e DGStat trimestrale.
- Calcolo indennità, IVA, spese vive e compensi.
- Archivio documentale.
- Dashboard e report.
- Predisposizione moduli Formazione, Orientamento, OCC e Crisi d'Impresa.

## Requisiti non funzionali
- Sicurezza.
- Tracciabilità.
- Backup.
- Performance.
- Modularità.
- Multi-sede.
- Predisposizione multi-organizzazione.
