# 13 - Security

## Requisiti
- Password cifrate.
- Autenticazione JWT.
- Permessi per ruolo.
- Audit log.
- Backup automatici.
- Protezione documenti.
- Separazione dati per organizzazione.

## Ruoli MVP
- Amministratore.
- Responsabile Organismo.
- Coordinamento.
- Segreteria.
- Mediatore.
- Lettura.
