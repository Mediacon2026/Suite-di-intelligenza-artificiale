# 06 - Business Rules

## Numerazione mediazioni
Il numero interno è progressivo annuale. Il numero DGStat è progressivo trimestrale e dipende dalla data di deposito.

## Trimestri DGStat
- I trimestre: gennaio-marzo.
- II trimestre: aprile-giugno.
- III trimestre: luglio-settembre.
- IV trimestre: ottobre-dicembre.

## Parti e avvocati
Ogni mediazione può avere più parti istanti, invitate e aderenti. Ogni parte può avere uno o più avvocati.

## Indennità
Il sistema deve distinguere imponibile, IVA, spese vive, raccomandate e totale. Le raccomandate non devono costituire base per il compenso mediatore.

## Compensi
Per Casarano il compenso mediatore è calcolato sul netto spettante, escludendo spese vive e raccomandate. Per sedi operative deve essere gestibile la retrocessione tra sede principale e sede operativa.

## Storico
Ogni modifica rilevante deve generare un record di audit.
