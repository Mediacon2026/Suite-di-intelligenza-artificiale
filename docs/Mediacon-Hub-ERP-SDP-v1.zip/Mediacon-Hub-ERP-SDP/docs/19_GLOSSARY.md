# 19 - Glossary

## ERP
Sistema gestionale integrato.

## CRM
Archivio centralizzato di contatti e relazioni.

## DGStat
Rilevazione statistica ministeriale trimestrale.

## OCC
Organismo di composizione della crisi.

## MVP
Versione minima utilizzabile del software.
