# 01 - Project Vision

Mediacon Hub ERP nasce per sostituire file Excel, modelli Word scollegati, archivi manuali e calcoli ripetitivi con un sistema unico, sicuro e scalabile.

## Visione finale
Una piattaforma utilizzabile da più sedi e più utenti, capace di gestire l'intero ciclo di vita delle pratiche e di assistere gli operatori con AI specializzate.

## Aree operative
- Organismo di Mediazione
- Ente di Formazione
- Polo di Orientamento
- Sovraindebitamento/OCC
- Crisi d'Impresa
- Advisor
