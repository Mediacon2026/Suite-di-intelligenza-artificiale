# 00 - Project Overview

## Nome progetto
Mediacon Hub ERP.

## Obiettivo
Centralizzare in una piattaforma unica le attività di Mediacon e delle aree collegate: mediazione, formazione, orientamento, OCC, crisi d'impresa, advisor, documenti, pagamenti, report e AI.

## Principio guida
Un solo archivio centrale dei soggetti, moduli separati ma collegati, workflow tracciabili, documenti generati automaticamente, report sempre aggiornati.

## MVP v1.0
La prima versione deve concentrarsi su Core, CRM, Mediazioni, Indennità, Documentale, DGStat e Dashboard.
