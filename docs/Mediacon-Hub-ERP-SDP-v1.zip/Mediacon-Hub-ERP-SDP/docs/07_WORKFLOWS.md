# 07 - Workflows

## Mediazione
1. Deposito pratica.
2. Verifica segreteria.
3. Assegnazione numero interno.
4. Calcolo trimestre e numero DGStat.
5. Inserimento parti e avvocati.
6. Nomina mediatore.
7. Convocazione.
8. Primo incontro.
9. Eventuali incontri successivi.
10. Chiusura.
11. Calcolo compensi.
12. Aggiornamento DGStat.
13. Archiviazione.

## Orientamento
Lead → contatto → preventivo → follow-up → documenti → immatricolazione → chiusura.

## OCC
Apertura pratica → debitore → creditori → documenti → relazione → deposito → udienza/scadenze → chiusura.
