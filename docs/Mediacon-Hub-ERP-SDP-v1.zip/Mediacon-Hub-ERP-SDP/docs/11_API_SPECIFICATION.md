# 11 - API Specification

## Autenticazione
POST /auth/login
POST /auth/logout
GET /auth/me

## Contatti
GET /contacts
POST /contacts
GET /contacts/{id}
PUT /contacts/{id}
DELETE /contacts/{id}

## Mediazioni
GET /mediations
POST /mediations
GET /mediations/{id}
PUT /mediations/{id}
POST /mediations/{id}/parties
POST /mediations/{id}/meetings
POST /mediations/{id}/close

## DGStat
GET /reports/dgstat?year={year}&quarter={quarter}&branch_id={branch_id}

## Documenti
POST /documents/upload
GET /documents/{id}
POST /documents/generate
