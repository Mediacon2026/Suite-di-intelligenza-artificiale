# 16 - Backlog

## Sprint 1
Setup repository, backend, frontend, database, Docker.

## Sprint 2
Autenticazione, utenti, ruoli, sedi.

## Sprint 3
CRM contatti.

## Sprint 4
Mediazioni base.

## Sprint 5
Parti, avvocati, mediatori, incontri.

## Sprint 6
Indennità, pagamenti, compensi.

## Sprint 7
Documentale e PDF.

## Sprint 8
DGStat e dashboard.
