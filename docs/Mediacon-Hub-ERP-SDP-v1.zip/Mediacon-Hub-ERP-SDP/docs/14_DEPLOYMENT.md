# 14 - Deployment

## Ambiente previsto
- Server Linux.
- Docker Compose.
- Nginx reverse proxy.
- PostgreSQL.
- Backend FastAPI.
- Frontend React build statico.

## Ambienti
- development.
- staging.
- production.

## Backup
Backup giornaliero database e documenti.
