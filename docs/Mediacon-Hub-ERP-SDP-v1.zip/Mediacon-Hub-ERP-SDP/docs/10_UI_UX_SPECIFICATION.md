# 10 - UI/UX Specification

## Menu principale
- Dashboard
- CRM
- Mediazioni
- Documenti
- Pagamenti
- DGStat
- Formazione
- Orientamento
- OCC
- Crisi d'Impresa
- AI Assistant
- Impostazioni

## Dashboard MVP
Card principali: mediazioni aperte, mediazioni chiuse, sospese, incontri settimana, pagamenti da incassare, compensi da liquidare, scadenze, documenti recenti.

## Schermata Mediazioni
Tabella con filtri per anno, trimestre, sede, mediatore, stato, esito, materia. Pulsanti: Nuova mediazione, Esporta, Report DGStat.

## Scheda Mediazione
Tab: dati generali, parti, avvocati, incontri, documenti, pagamenti, indennità, compensi, storico.
