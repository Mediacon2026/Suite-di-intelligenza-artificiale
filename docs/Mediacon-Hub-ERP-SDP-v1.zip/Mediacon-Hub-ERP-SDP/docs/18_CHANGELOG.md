# 18 - Changelog

## v1.0
Creato Software Design Package iniziale.
