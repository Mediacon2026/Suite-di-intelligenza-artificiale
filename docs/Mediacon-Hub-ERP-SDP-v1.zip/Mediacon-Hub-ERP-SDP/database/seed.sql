-- Seed iniziale Mediacon Hub ERP

INSERT INTO roles (name, description) VALUES
('admin', 'Amministratore sistema'),
('responsabile_organismo', 'Responsabile Organismo'),
('coordinamento', 'Coordinamento e contabilità'),
('segreteria', 'Segreteria'),
('mediatore', 'Mediatore'),
('lettura', 'Solo lettura');

INSERT INTO organizations (name, email, pec) VALUES
('Mediacon S.r.l.', 'info@mediacon.org', 'mediacon@arubapec.it');

INSERT INTO branches (organization_id, name, address, city, province, phone, email, pec) VALUES
(1, 'Casarano', 'Via Bruno Buozzi 10', 'Casarano', 'LE', '0833513189', 'info@mediacon.org', 'mediacon@arubapec.it'),
(1, 'Pachino', 'Via Fratelli Bandiera 82', 'Pachino', 'SR', NULL, 'info@mediacon.org', 'mediacon@arubapec.it'),
(1, 'Napoli', 'Via Enrico Pessina 66', 'Napoli', 'NA', NULL, 'info@mediacon.org', 'mediacon@arubapec.it');
