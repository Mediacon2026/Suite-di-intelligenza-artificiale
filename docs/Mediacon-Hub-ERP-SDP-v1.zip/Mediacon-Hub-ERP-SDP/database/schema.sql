-- Mediacon Hub ERP - PostgreSQL schema MVP v1.0

CREATE TABLE organizations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    tax_code VARCHAR(50),
    vat_number VARCHAR(50),
    email VARCHAR(255),
    pec VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE branches (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL REFERENCES organizations(id),
    name VARCHAR(255) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    province VARCHAR(10),
    phone VARCHAR(50),
    email VARCHAR(255),
    pec VARCHAR(255),
    active BOOLEAN DEFAULT TRUE
);

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL REFERENCES organizations(id),
    branch_id INTEGER REFERENCES branches(id),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT
);

CREATE TABLE user_roles (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    role_id INTEGER REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE contacts (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL REFERENCES organizations(id),
    contact_type VARCHAR(50) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    company_name VARCHAR(255),
    tax_code VARCHAR(50),
    vat_number VARCHAR(50),
    email VARCHAR(255),
    pec VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    province VARCHAR(10),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE mediators (
    id SERIAL PRIMARY KEY,
    contact_id INTEGER NOT NULL REFERENCES contacts(id),
    branch_id INTEGER REFERENCES branches(id),
    qualification VARCHAR(255),
    compensation_percentage NUMERIC(5,2),
    active BOOLEAN DEFAULT TRUE
);

CREATE TABLE mediations (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL REFERENCES organizations(id),
    branch_id INTEGER NOT NULL REFERENCES branches(id),
    internal_number INTEGER NOT NULL,
    internal_year INTEGER NOT NULL,
    dgstat_number INTEGER,
    dgstat_quarter INTEGER,
    deposit_date DATE NOT NULL,
    first_meeting_date DATE,
    closing_date DATE,
    duration_days INTEGER,
    subject TEXT,
    matter VARCHAR(255),
    dispute_value NUMERIC(14,2),
    mediation_type VARCHAR(100),
    status VARCHAR(100) NOT NULL DEFAULT 'depositata',
    outcome VARCHAR(100),
    mediator_id INTEGER REFERENCES mediators(id),
    meeting_mode VARCHAR(100),
    meetings_count INTEGER DEFAULT 0,
    suspended BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (organization_id, internal_year, internal_number)
);

CREATE TABLE mediation_parties (
    id SERIAL PRIMARY KEY,
    mediation_id INTEGER NOT NULL REFERENCES mediations(id) ON DELETE CASCADE,
    contact_id INTEGER NOT NULL REFERENCES contacts(id),
    party_role VARCHAR(50) NOT NULL,
    present BOOLEAN DEFAULT FALSE,
    legal_aid BOOLEAN DEFAULT FALSE,
    notes TEXT
);

CREATE TABLE mediation_lawyers (
    id SERIAL PRIMARY KEY,
    mediation_id INTEGER NOT NULL REFERENCES mediations(id) ON DELETE CASCADE,
    party_id INTEGER REFERENCES mediation_parties(id) ON DELETE CASCADE,
    lawyer_contact_id INTEGER NOT NULL REFERENCES contacts(id),
    role VARCHAR(100),
    power_of_attorney BOOLEAN DEFAULT FALSE,
    notes TEXT
);

CREATE TABLE mediation_meetings (
    id SERIAL PRIMARY KEY,
    mediation_id INTEGER NOT NULL REFERENCES mediations(id) ON DELETE CASCADE,
    meeting_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    mode VARCHAR(100),
    location_or_link TEXT,
    outcome VARCHAR(100),
    notes TEXT
);

CREATE TABLE mediation_fees (
    id SERIAL PRIMARY KEY,
    mediation_id INTEGER NOT NULL REFERENCES mediations(id) ON DELETE CASCADE,
    fee_type VARCHAR(100),
    taxable_amount NUMERIC(12,2) DEFAULT 0,
    vat_amount NUMERIC(12,2) DEFAULT 0,
    living_expenses NUMERIC(12,2) DEFAULT 0,
    registered_letters NUMERIC(12,2) DEFAULT 0,
    total_amount NUMERIC(12,2) DEFAULT 0,
    paid BOOLEAN DEFAULT FALSE,
    payment_date DATE,
    payment_method VARCHAR(100),
    notes TEXT
);

CREATE TABLE mediator_compensations (
    id SERIAL PRIMARY KEY,
    mediation_id INTEGER NOT NULL REFERENCES mediations(id) ON DELETE CASCADE,
    mediator_id INTEGER NOT NULL REFERENCES mediators(id),
    calculation_base NUMERIC(12,2),
    percentage NUMERIC(5,2),
    amount NUMERIC(12,2),
    paid BOOLEAN DEFAULT FALSE,
    payment_date DATE
);

CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL REFERENCES organizations(id),
    area VARCHAR(100) NOT NULL,
    reference_id INTEGER NOT NULL,
    document_type VARCHAR(100),
    file_name VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    uploaded_by INTEGER REFERENCES users(id),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE audit_logs (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER REFERENCES organizations(id),
    user_id INTEGER REFERENCES users(id),
    entity_name VARCHAR(100),
    entity_id INTEGER,
    action VARCHAR(100),
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
