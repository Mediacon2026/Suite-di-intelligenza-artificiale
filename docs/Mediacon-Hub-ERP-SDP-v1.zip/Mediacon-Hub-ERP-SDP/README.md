# Mediacon Hub ERP

Piattaforma gestionale intelligente per Organismo di Mediazione, Ente di Formazione, Polo di Orientamento, OCC, Crisi d'Impresa e Advisor.

## Stato progetto

Fase attuale: Software Design Package v1.0.

## Moduli MVP v1.0

- Core
- CRM
- Mediazioni
- Documentale
- Indennità
- DGStat
- Dashboard

## Stack previsto

- Backend: Python FastAPI
- Frontend: React
- Database: PostgreSQL
- AI: OpenAI API
- Deploy: Docker, Nginx, Linux
